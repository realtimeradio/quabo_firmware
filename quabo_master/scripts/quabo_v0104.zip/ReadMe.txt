Three files are here:
(1) quabo_0104_22D14F8E.bin
    This is the silver firmware.
(2) quabo_GOLD.bin
    This is the gold firmware.
    After you upload it to the board, you will never need to change it.
(3) quabo_fwid.bit
    This file is useful, when you mess up the gold firmware on the board.
    You should connect a JTAG to the board, and download this file.
